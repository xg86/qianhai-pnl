/*
 * Subscriber
 *
 * ION Trading U.K. Limited supplies this software code is for testing purposes
 * only. The scope of this software code is exclusively limited to the
 * demonstration of the structure of an application using the ION(tm) Common
 * Market and ION Trading U.K. Limited does not guarantee the correct behavior
 * of any deployed application using this software code.
 * This software code has not been thoroughly tested under all conditions.
 * ION, therefore, cannot guarantee or imply reliability, serviceability, or
 * function of this software.
 * Any use of this software outside of this defined scope is the sole
 * responsibility of the user.
 *
 * ION Trading ltd (2005)
 */

package com.iontrading.samples.simpleSubscriber;

import com.iontrading.mkv.Mkv;
import com.iontrading.mkv.MkvComponent;
import com.iontrading.mkv.MkvObject;
import com.iontrading.mkv.MkvRecord;
import com.iontrading.mkv.MkvSupply;
import com.iontrading.mkv.MkvType;
import com.iontrading.mkv.enums.MkvObjectType;
import com.iontrading.mkv.enums.MkvPlatformEvent;
import com.iontrading.mkv.events.MkvPlatformListener;
import com.iontrading.mkv.events.MkvPublishListener;
import com.iontrading.mkv.events.MkvRecordListener;
import com.iontrading.mkv.exceptions.MkvException;
import com.iontrading.mkv.qos.MkvQoS;

public class Subscriber {
    
    private static final String SOURCE = "MYPUB";
    private static final String RECORD_PREFIX = "EUR.PRICE." + SOURCE + ".";
    private static final String RECORD_ID = "FGBLH3";
    private static final String RECORD_NAME = RECORD_PREFIX + RECORD_ID;
    
    /** Creates a new instance of Subscriber */
    public Subscriber(String[] args) {
        MkvQoS qos = new MkvQoS();
        qos.setArgs(args);
        qos.setPlatformListeners(new MkvPlatformListener[] {new PlatformListener()});
        try {
            Mkv mkv = Mkv.start(qos);
        } catch (MkvException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        Subscriber sub = new Subscriber(args);
    }
    
    private class PlatformListener implements MkvPlatformListener {

		public void onComponent(MkvComponent comp, boolean start) {}

		public void onConnect(String comp, boolean start) {}

		public void onMain(MkvPlatformEvent event) {
			if (event.equals(MkvPlatformEvent.START)) {
				Mkv.getInstance().getPublishManager().addPublishListener(new PublishListener());
			}
		}
    }
    
    private class DataListener implements MkvRecordListener {
        
    	public void onPartialUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply, boolean isSnapshot) {
        }
        
        public void onFullUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply, boolean isSnapshot) {
            try {
                String out = "Record " + mkvRecord.getName() + " : ";
                int cursor = mkvSupply.firstIndex();
                while (cursor!=-1) {
                    out +=  mkvRecord.getMkvType().getFieldName(cursor) +
                            " {" + mkvSupply.getObject(cursor) + "} ";
                    cursor = mkvSupply.nextIndex(cursor);
                }
                System.out.println((isSnapshot?"Snp ":"Upd ") + out);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private class PublishListener implements MkvPublishListener {
    	
    	void subscribeRecord(MkvRecord rec) {
            try {
                MkvRecordListener listener = new DataListener();
                rec.subscribe(new String[] {"BID", "ASK"}, listener);
            } catch (Exception e) {
                e.printStackTrace();
            }
    	}
    	
    	public void onPublish(MkvObject mkvObject, boolean start, boolean dwl) {
        	if (start && !dwl) {
	            if (mkvObject.getMkvObjectType().equals(MkvObjectType.RECORD)) {
	                if (mkvObject.getName().equals(RECORD_NAME)) {
	                    System.out.println("Intercepted " + (start?"":"un") +
	                            "publication : " + mkvObject.getName() + " Dwl {" + dwl + "}");
	                    subscribeRecord(((MkvRecord)mkvObject));
	                }
	            }
        	}
        }
        
        public void onPublishIdle(String component, boolean start) {
        	if (start) {
        		MkvRecord rec = Mkv.getInstance().getPublishManager().getMkvRecord(RECORD_NAME);
        		if (rec!=null) {
        			subscribeRecord(rec);
        		}
        	}
        }

        public void onSubscribe(MkvObject mkvObject) {
            // not interested in this event because our component is a pure subscriber
            // and is not supposed receiving request for subscriptions.
        }
        
    }
}
