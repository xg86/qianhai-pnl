/*
 * ChainSubscriber
 *
 * ION Trading U.K. Limited supplies this software code is for testing purposes
 * only. The scope of this software code is exclusively limited to the
 * demonstration of the structure of an application using the ION(tm) Common
 * Market and ION Trading U.K. Limited does not guarantee the correct behavior
 * of any deployed application using this software code.
 * This software code has not been thoroughly tested under all conditions.
 * ION, therefore, cannot guarantee or imply reliability, serviceability, or
 * function of this software.
 * Any use of this software outside of this defined scope is the sole
 * responsibility of the user.
 *
 * ION Trading ltd (2005)
 */

package com.iontrading.samples.simpleChainSubscriber;

import com.iontrading.mkv.Mkv;
import com.iontrading.mkv.MkvChain;
import com.iontrading.mkv.MkvComponent;
import com.iontrading.mkv.MkvObject;
import com.iontrading.mkv.MkvRecord;
import com.iontrading.mkv.MkvSupply;
import com.iontrading.mkv.enums.MkvChainAction;
import com.iontrading.mkv.enums.MkvObjectType;
import com.iontrading.mkv.enums.MkvPlatformEvent;
import com.iontrading.mkv.events.MkvChainListener;
import com.iontrading.mkv.events.MkvPlatformListener;
import com.iontrading.mkv.events.MkvPublishListener;
import com.iontrading.mkv.events.MkvRecordListener;
import com.iontrading.mkv.exceptions.MkvConnectionException;
import com.iontrading.mkv.exceptions.MkvException;
import com.iontrading.mkv.exceptions.MkvObjectNotAvailableException;
import com.iontrading.mkv.qos.MkvQoS;

public class ChainSubscriber implements MkvPlatformListener, MkvPublishListener, MkvChainListener,
        MkvRecordListener {
    
    private String _fields[] = { "ID", "BID", "QTY" };
    private static final String SOURCE = "MYPUB";
    private static final String CHAIN_NAME = "EUR.PRICE." + SOURCE + ".QUOTES";
     
    public ChainSubscriber(String[] args) {
        // create the initial configuration used to start the engine.
        MkvQoS qos = new MkvQoS();
        qos.setPlatformListeners(new MkvPlatformListener[] {this});
        try {
            // Start the engine and get back the instance of Mkv (unique during the
            // life of a component).
            Mkv mkv = Mkv.start(qos);
        } catch (MkvException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        ChainSubscriber subscriber = new ChainSubscriber(args);
    }
    
    public void onPublish(MkvObject mkvObject, boolean start, boolean download) {
        if (start) {
            if (!download) {
                // a new object has been published runtime
                // check if the component is interested in.
                if (mkvObject.getMkvObjectType().equals(MkvObjectType.CHAIN) &&
                        mkvObject.getName().equals(CHAIN_NAME)) {
                    try {
                        ((MkvChain)mkvObject).subscribe(this);
                        // the chain has been subscribed to
                    } catch (MkvObjectNotAvailableException e) {
                        e.printStackTrace();
                        // the object does not exists in the datadictionary
                    } catch (MkvConnectionException e) {
                        e.printStackTrace();
                        // the subscription failed because of a connection problem
                    }
                } else {
                    // the component is not interested in the publication
                }
            } else {
                // the publication is part of a download, wait for the idle.
            }
        } else {
            // handle the un-publish.
            // Incase free the resources linked to the publication in case it has been
            // subscribed to.
        }
    }
    
    public void onPublishIdle(String component, boolean start) {
        MkvChain c = Mkv.getInstance().getPublishManager().getMkvChain(CHAIN_NAME);
        if (c!=null) {
            try {
                c.subscribe(this);
                // the chain has been subscribed to
            } catch (MkvObjectNotAvailableException e) {
                e.printStackTrace();
                // the object does not exists in the datadictionary
            } catch (MkvConnectionException e) {
                e.printStackTrace();
                // the subscription failed because of a connection problem
            }
        }
    }
    
    public void onSubscribe(MkvObject mkvObject) {
        /*
         * Not interested in this event.
         * Publishers are usually interested in incoming subscriptions.
         */
    }
    
    public void onPartialUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply, boolean isSnapshot) {}
    
    public void onFullUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply, boolean isSnapshot) {
        try {
            String out = "Record " + mkvRecord.getName() + " : ";
            int cursor = mkvSupply.firstIndex();
            while (cursor!=-1) {
                out +=  mkvRecord.getMkvType().getFieldName(cursor) +
                        " {" + mkvSupply.getObject(cursor) + "} ";
                cursor = mkvSupply.nextIndex(cursor);
            }
            System.out.println((isSnapshot?"Snp ":"Upd ") + out);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void onSupply(MkvChain mkvChain, String recordName, int position,
            MkvChainAction mkvChainAction) {
        try {
            switch(mkvChainAction.intValue()) {
                case MkvChainAction.IDLE_code:
                    // The component has downloaded the current content of the chain.
                    // Ususally this event is caught after the subscribtion to the chain.
                    // NB. The argument record and position are useless in this case
                    System.out.println("Chain IDLE");
                    for(int i = 0; i < mkvChain.size(); i++) {
                        String _recordName = (String)mkvChain.get(i);
                        subscribeToRecord(_recordName);
                    }
                    break;
                case MkvChainAction.RESET_code:
                    // the chain has been emptied.
                    // NB. The argument record and position are useless in this case
                    System.out.println("Chain RESET");
                    for(int i = 0; i < mkvChain.size(); i++) {
                        String _recordName = (String)mkvChain.get(i);
                        unsubscribeToRecord(_recordName);
                    }
                    break;
                case MkvChainAction.INSERT_code:
                case MkvChainAction.APPEND_code:
                {
                    // a record has been appended to the chain.
                    System.out.println("Chain APPEND : " + recordName);
                    subscribeToRecord(recordName);
                    break;
                }
                case MkvChainAction.DELETE_code:
                {
                    // a record has been removed from the chain.
                    System.out.println("Chain DELETE : " + recordName);
                    unsubscribeToRecord(recordName);
                    break;
                }
            }
        } catch (MkvException e) {
            e.printStackTrace();
        }
    }
    
    private synchronized void subscribeToRecord(String recName) throws MkvException {
        MkvRecord rec =
                Mkv.getInstance().getPublishManager().getMkvRecord(recName);
        // ensure not to subscribe to an already subscribed record. This would
        // cause the receiving of an unnecessary snaphot
        if (rec!=null && !rec.isSubscribed(this, _fields)) {
            System.out.println("Subscribing " + recName);
            rec.subscribe(this);
        }
    }

    private void unsubscribeToRecord(String recName) throws MkvException {
        MkvRecord rec =
                Mkv.getInstance().getPublishManager().getMkvRecord(recName);
        if (rec!=null) {
            System.out.println("Unsubscribing " + recName);
            rec.unsubscribe(this);
        }
    }

	public void onComponent(MkvComponent comp, boolean start) {}

	public void onConnect(String comp, boolean start) {}

	public void onMain(MkvPlatformEvent event) {
		if (event.equals(MkvPlatformEvent.START)) {
			Mkv.getInstance().getPublishManager().addPublishListener(this);
		}
	}
}