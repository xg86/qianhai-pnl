# 客户原始成交

来源：原 `input/qianhai2/原始交易/`。

| 文件 | 用途 |
|---|---|
| `gs-1.xls` | 固收1 |
| `gs-2.xls` | 固收2 |
| `qy-3.xls` | 权益3（成交到 2026-05-29） |
| `qy-4.xls` | 权益4 |
| `可转债测试数据.xls` | 固收3 / 转债 |
| `\incremental2\incremental2_补充.txt` | 两笔补充交易 |
| `\incremental2\新综合信息查询_场外执行成交_固收1（）0101-0831.xls` | 基金交易 |
| `\incremental2\固收3私募估值表` | 私募债的估值表，应该不需要|

重生 CSV：`python clients/qianhai/pre/scripts/gen_qianhai2_from_trades.py`（在引擎根目录跑）。
